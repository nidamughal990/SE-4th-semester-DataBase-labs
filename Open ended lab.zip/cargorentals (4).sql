-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2026 at 12:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cargorentals`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `RegisterRental` (IN `p_CustomerID` INT, IN `p_VehicleID` INT, IN `p_RentalDate` DATE, IN `p_ReturnDate` DATE)   BEGIN
    DECLARE v_DailyRate DECIMAL(10,2);
    DECLARE v_RentalCharge DECIMAL(10,2);
    DECLARE v_Days INT;
    DECLARE v_VehicleStatus VARCHAR(20);

    SELECT DailyRate, VehicleStatus
    INTO v_DailyRate, v_VehicleStatus
    FROM Vehicles
    WHERE VehicleID = p_VehicleID;

    IF v_VehicleStatus <> 'Available' THEN

        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Vehicle is not available';

    ELSEIF p_ReturnDate < p_RentalDate THEN

        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Return date cannot be before rental date';

    ELSE

        SET v_Days = DATEDIFF(p_ReturnDate, p_RentalDate);

        IF v_Days = 0 THEN
            SET v_Days = 1;
        END IF;

        SET v_RentalCharge = v_Days * v_DailyRate;

        INSERT INTO Rentals
        (
            CustomerID,
            VehicleID,
            RentalDate,
            ExpectedReturnDate,
            RentalCharge,
            RentalStatus
        )
        VALUES
        (
            p_CustomerID,
            p_VehicleID,
            p_RentalDate,
            p_ReturnDate,
            v_RentalCharge,
            'Active'
        );

    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustomerID` int(11) NOT NULL,
  `CustomerName` varchar(100) NOT NULL,
  `CustomerPhone` varchar(20) NOT NULL,
  `CustomerEmail` varchar(100) DEFAULT NULL,
  `DrivingLicense` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustomerID`, `CustomerName`, `CustomerPhone`, `CustomerEmail`, `DrivingLicense`) VALUES
(1, 'Ali Khan', '0300-1234567', 'ali@gmail.com', 'DL1001'),
(2, 'Sara Ahmed', '0311-2345678', 'sara@gmail.com', 'DL1002'),
(3, 'Usman Malik', '0322-3456789', 'usman@gmail.com', 'DL1003'),
(4, 'Ayesha Noor', '0333-4567890', 'ayesha@gmail.com', 'DL1004'),
(5, 'Hamza Raza', '0344-5678901', 'hamza@gmail.com', 'DL1005');

-- --------------------------------------------------------

--
-- Table structure for table `customers_3nf`
--

CREATE TABLE `customers_3nf` (
  `CustomerID` int(11) NOT NULL,
  `CustomerName` varchar(100) NOT NULL,
  `CustomerPhone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers_3nf`
--

INSERT INTO `customers_3nf` (`CustomerID`, `CustomerName`, `CustomerPhone`) VALUES
(1, 'Ali Khan', '0300-1234567');

-- --------------------------------------------------------

--
-- Table structure for table `customer_2nf`
--

CREATE TABLE `customer_2nf` (
  `CustomerID` int(11) NOT NULL,
  `CustomerName` varchar(100) NOT NULL,
  `CustomerPhone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_2nf`
--

INSERT INTO `customer_2nf` (`CustomerID`, `CustomerName`, `CustomerPhone`) VALUES
(1, 'Ali Khan', '0300-1234567');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` int(11) NOT NULL,
  `RentalID` int(11) NOT NULL,
  `PaymentDate` date NOT NULL,
  `PaymentAmount` decimal(10,2) NOT NULL CHECK (`PaymentAmount` > 0),
  `PaymentMethod` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `RentalID`, `PaymentDate`, `PaymentAmount`, `PaymentMethod`) VALUES
(1, 1, '2026-09-01', 15000.00, 'Cash'),
(2, 2, '2026-09-10', 18000.00, 'Card'),
(3, 3, '2026-08-20', 12000.00, 'Online');

-- --------------------------------------------------------

--
-- Table structure for table `payments_3nf`
--

CREATE TABLE `payments_3nf` (
  `PaymentID` int(11) NOT NULL,
  `RentalID` varchar(10) NOT NULL,
  `PaymentAmount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments_3nf`
--

INSERT INTO `payments_3nf` (`PaymentID`, `RentalID`, `PaymentAmount`) VALUES
(1, 'R001', 15000.00);

-- --------------------------------------------------------

--
-- Stand-in structure for view `rentalreport`
-- (See below for the actual view)
--
CREATE TABLE `rentalreport` (
`RentalID` int(11)
,`CustomerName` varchar(100)
,`CustomerPhone` varchar(20)
,`VehicleNumber` varchar(20)
,`VehicleModel` varchar(100)
,`RentalDate` date
,`ExpectedReturnDate` date
,`ActualReturnDate` date
,`RentalCharge` decimal(10,2)
,`PaymentAmount` decimal(10,2)
,`PaymentDate` date
,`PaymentMethod` varchar(30)
,`RentalStatus` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `RentalID` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `VehicleID` int(11) NOT NULL,
  `RentalDate` date NOT NULL,
  `ExpectedReturnDate` date NOT NULL,
  `ActualReturnDate` date DEFAULT NULL,
  `RentalCharge` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RentalStatus` varchar(20) NOT NULL DEFAULT 'Active'
) ;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`RentalID`, `CustomerID`, `VehicleID`, `RentalDate`, `ExpectedReturnDate`, `ActualReturnDate`, `RentalCharge`, `RentalStatus`) VALUES
(1, 1, 1, '2026-09-01', '2026-09-04', '2026-09-04', 15000.00, 'Completed'),
(2, 2, 4, '2026-09-10', '2026-09-14', NULL, 18000.00, 'Active'),
(3, 3, 2, '2026-08-20', '2026-08-22', '2026-08-22', 12000.00, 'Completed'),
(4, 4, 3, '2026-09-20', '2026-09-23', '2026-09-23', 12000.00, 'Completed');

--
-- Triggers `rentals`
--
DELIMITER $$
CREATE TRIGGER `trg_vehicle_rented` AFTER INSERT ON `rentals` FOR EACH ROW BEGIN
    IF NEW.RentalStatus = 'Active' THEN
        UPDATE Vehicles
        SET VehicleStatus = 'Rented'
        WHERE VehicleID = NEW.VehicleID;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_vehicle_returned` AFTER UPDATE ON `rentals` FOR EACH ROW BEGIN
    IF NEW.RentalStatus = 'Completed'
       AND OLD.RentalStatus <> 'Completed' THEN

        UPDATE Vehicles
        SET VehicleStatus = 'Available'
        WHERE VehicleID = NEW.VehicleID;

    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `rentals_3nf`
--

CREATE TABLE `rentals_3nf` (
  `RentalID` varchar(10) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `VehicleID` int(11) NOT NULL,
  `RentalDate` date NOT NULL,
  `ReturnDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rentals_3nf`
--

INSERT INTO `rentals_3nf` (`RentalID`, `CustomerID`, `VehicleID`, `RentalDate`, `ReturnDate`) VALUES
('R001', 1, 1, '2026-09-01', '2026-09-04');

-- --------------------------------------------------------

--
-- Table structure for table `rental_1nf`
--

CREATE TABLE `rental_1nf` (
  `RentalID` varchar(10) NOT NULL,
  `CustomerName` varchar(100) DEFAULT NULL,
  `CustomerPhone` varchar(20) DEFAULT NULL,
  `VehicleNumber` varchar(20) DEFAULT NULL,
  `VehicleModel` varchar(100) DEFAULT NULL,
  `DailyRate` decimal(10,2) DEFAULT NULL,
  `RentalDate` date DEFAULT NULL,
  `ReturnDate` date DEFAULT NULL,
  `PaymentAmount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rental_1nf`
--

INSERT INTO `rental_1nf` (`RentalID`, `CustomerName`, `CustomerPhone`, `VehicleNumber`, `VehicleModel`, `DailyRate`, `RentalDate`, `ReturnDate`, `PaymentAmount`) VALUES
('R001', 'Ali Khan', '0300-1234567', 'ABC-123', 'Toyota Corolla', 5000.00, '2026-09-01', '2026-09-04', 15000.00);

-- --------------------------------------------------------

--
-- Table structure for table `rental_2nf`
--

CREATE TABLE `rental_2nf` (
  `RentalID` varchar(10) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `VehicleID` int(11) NOT NULL,
  `RentalDate` date NOT NULL,
  `ReturnDate` date NOT NULL,
  `PaymentAmount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rental_2nf`
--

INSERT INTO `rental_2nf` (`RentalID`, `CustomerID`, `VehicleID`, `RentalDate`, `ReturnDate`, `PaymentAmount`) VALUES
('R001', 1, 1, '2026-09-01', '2026-09-04', 15000.00);

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `VehicleID` int(11) NOT NULL,
  `VehicleNumber` varchar(20) NOT NULL,
  `VehicleModel` varchar(100) NOT NULL,
  `VehicleType` varchar(50) NOT NULL,
  `DailyRate` decimal(10,2) NOT NULL CHECK (`DailyRate` > 0),
  `VehicleStatus` varchar(20) NOT NULL DEFAULT 'Available'
) ;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`VehicleID`, `VehicleNumber`, `VehicleModel`, `VehicleType`, `DailyRate`, `VehicleStatus`) VALUES
(1, 'ABC-123', 'Toyota Corolla', 'Sedan', 5000.00, 'Rented'),
(2, 'XYZ-456', 'Honda Civic', 'Sedan', 6000.00, 'Available'),
(3, 'DEF-789', 'Suzuki Swift', 'Hatchback', 4000.00, 'Available'),
(4, 'LMN-321', 'Toyota Yaris', 'Sedan', 4500.00, 'Rented'),
(5, 'PQR-654', 'Kia Sportage', 'SUV', 8000.00, 'Maintenance');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles_3nf`
--

CREATE TABLE `vehicles_3nf` (
  `VehicleID` int(11) NOT NULL,
  `VehicleNumber` varchar(20) NOT NULL,
  `VehicleModel` varchar(100) NOT NULL,
  `DailyRate` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles_3nf`
--

INSERT INTO `vehicles_3nf` (`VehicleID`, `VehicleNumber`, `VehicleModel`, `DailyRate`) VALUES
(1, 'ABC-123', 'Toyota Corolla', 5000.00);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_2nf`
--

CREATE TABLE `vehicle_2nf` (
  `VehicleID` int(11) NOT NULL,
  `VehicleNumber` varchar(20) NOT NULL,
  `VehicleModel` varchar(100) NOT NULL,
  `DailyRate` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicle_2nf`
--

INSERT INTO `vehicle_2nf` (`VehicleID`, `VehicleNumber`, `VehicleModel`, `DailyRate`) VALUES
(1, 'ABC-123', 'Toyota Corolla', 5000.00);

-- --------------------------------------------------------

--
-- Structure for view `rentalreport`
--
DROP TABLE IF EXISTS `rentalreport`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `rentalreport`  AS SELECT `r`.`RentalID` AS `RentalID`, `c`.`CustomerName` AS `CustomerName`, `c`.`CustomerPhone` AS `CustomerPhone`, `v`.`VehicleNumber` AS `VehicleNumber`, `v`.`VehicleModel` AS `VehicleModel`, `r`.`RentalDate` AS `RentalDate`, `r`.`ExpectedReturnDate` AS `ExpectedReturnDate`, `r`.`ActualReturnDate` AS `ActualReturnDate`, `r`.`RentalCharge` AS `RentalCharge`, `p`.`PaymentAmount` AS `PaymentAmount`, `p`.`PaymentDate` AS `PaymentDate`, `p`.`PaymentMethod` AS `PaymentMethod`, `r`.`RentalStatus` AS `RentalStatus` FROM (((`rentals` `r` join `customers` `c` on(`r`.`CustomerID` = `c`.`CustomerID`)) join `vehicles` `v` on(`r`.`VehicleID` = `v`.`VehicleID`)) left join `payments` `p` on(`r`.`RentalID` = `p`.`RentalID`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerID`),
  ADD UNIQUE KEY `CustomerPhone` (`CustomerPhone`),
  ADD UNIQUE KEY `DrivingLicense` (`DrivingLicense`),
  ADD UNIQUE KEY `CustomerEmail` (`CustomerEmail`);

--
-- Indexes for table `customers_3nf`
--
ALTER TABLE `customers_3nf`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `customer_2nf`
--
ALTER TABLE `customer_2nf`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `RentalID` (`RentalID`);

--
-- Indexes for table `payments_3nf`
--
ALTER TABLE `payments_3nf`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `RentalID` (`RentalID`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`RentalID`),
  ADD KEY `idx_rentals_customer` (`CustomerID`),
  ADD KEY `idx_rentals_vehicle` (`VehicleID`),
  ADD KEY `idx_rentals_status` (`RentalStatus`);

--
-- Indexes for table `rentals_3nf`
--
ALTER TABLE `rentals_3nf`
  ADD PRIMARY KEY (`RentalID`),
  ADD KEY `CustomerID` (`CustomerID`),
  ADD KEY `VehicleID` (`VehicleID`);

--
-- Indexes for table `rental_1nf`
--
ALTER TABLE `rental_1nf`
  ADD PRIMARY KEY (`RentalID`);

--
-- Indexes for table `rental_2nf`
--
ALTER TABLE `rental_2nf`
  ADD PRIMARY KEY (`RentalID`),
  ADD KEY `CustomerID` (`CustomerID`),
  ADD KEY `VehicleID` (`VehicleID`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`VehicleID`),
  ADD UNIQUE KEY `VehicleNumber` (`VehicleNumber`);

--
-- Indexes for table `vehicles_3nf`
--
ALTER TABLE `vehicles_3nf`
  ADD PRIMARY KEY (`VehicleID`),
  ADD UNIQUE KEY `VehicleNumber` (`VehicleNumber`);

--
-- Indexes for table `vehicle_2nf`
--
ALTER TABLE `vehicle_2nf`
  ADD PRIMARY KEY (`VehicleID`),
  ADD UNIQUE KEY `VehicleNumber` (`VehicleNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customers_3nf`
--
ALTER TABLE `customers_3nf`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_2nf`
--
ALTER TABLE `customer_2nf`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payments_3nf`
--
ALTER TABLE `payments_3nf`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rentals`
--
ALTER TABLE `rentals`
  MODIFY `RentalID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `VehicleID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicles_3nf`
--
ALTER TABLE `vehicles_3nf`
  MODIFY `VehicleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vehicle_2nf`
--
ALTER TABLE `vehicle_2nf`
  MODIFY `VehicleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`RentalID`) REFERENCES `rentals` (`RentalID`);

--
-- Constraints for table `payments_3nf`
--
ALTER TABLE `payments_3nf`
  ADD CONSTRAINT `payments_3nf_ibfk_1` FOREIGN KEY (`RentalID`) REFERENCES `rentals_3nf` (`RentalID`);

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerID`),
  ADD CONSTRAINT `rentals_ibfk_2` FOREIGN KEY (`VehicleID`) REFERENCES `vehicles` (`VehicleID`);

--
-- Constraints for table `rentals_3nf`
--
ALTER TABLE `rentals_3nf`
  ADD CONSTRAINT `rentals_3nf_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customers_3nf` (`CustomerID`),
  ADD CONSTRAINT `rentals_3nf_ibfk_2` FOREIGN KEY (`VehicleID`) REFERENCES `vehicles_3nf` (`VehicleID`);

--
-- Constraints for table `rental_2nf`
--
ALTER TABLE `rental_2nf`
  ADD CONSTRAINT `rental_2nf_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customer_2nf` (`CustomerID`),
  ADD CONSTRAINT `rental_2nf_ibfk_2` FOREIGN KEY (`VehicleID`) REFERENCES `vehicle_2nf` (`VehicleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
