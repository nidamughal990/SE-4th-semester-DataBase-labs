-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2026 at 12:48 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore_normalization`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `BookID` varchar(10) NOT NULL,
  `BookTitle` varchar(100) DEFAULT NULL,
  `Publisher` varchar(50) DEFAULT NULL,
  `UnitPrice` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`BookID`, `BookTitle`, `Publisher`, `UnitPrice`) VALUES
('B-1', 'SQL Basics', 'Pearson', 1200.00),
('B-2', 'Python 101', 'OReilly', 1500.00),
('B-3', 'Networks', 'Pearson', 1800.00);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `BookID` varchar(10) DEFAULT NULL,
  `BookTitle` varchar(100) DEFAULT NULL,
  `Publisher` varchar(50) DEFAULT NULL,
  `UnitPrice` decimal(10,2) DEFAULT NULL,
  `Qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`BookID`, `BookTitle`, `Publisher`, `UnitPrice`, `Qty`) VALUES
('B-1', 'SQL Basics', 'Pearson', 1200.00, 1),
('B-2', 'Python 101', 'OReilly', 1500.00, 2),
('B-1', 'SQL Basics', 'Pearson', 1200.00, 3),
('B-3', 'Networks', 'Pearson', 1800.00, 1),
('B-2', 'Python 101', 'OReilly', 1500.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `book_2nf`
--

CREATE TABLE `book_2nf` (
  `BookID` varchar(10) NOT NULL,
  `BookTitle` varchar(100) DEFAULT NULL,
  `Publisher` varchar(50) DEFAULT NULL,
  `UnitPrice` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_2nf`
--

INSERT INTO `book_2nf` (`BookID`, `BookTitle`, `Publisher`, `UnitPrice`) VALUES
('B-1', 'SQL Basics', 'Pearson', 1200.00),
('B-2', 'Python 101', 'OReilly', 1500.00),
('B-3', 'Networks', 'Pearson', 1800.00);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustID` varchar(10) NOT NULL,
  `CustName` varchar(50) DEFAULT NULL,
  `CustEmail` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustID`, `CustName`, `CustEmail`) VALUES
('C-11', 'Bilal', 'bilal@x.com'),
('C-12', 'Areeba', 'areeba@x.com');

-- --------------------------------------------------------

--
-- Table structure for table `orderbook`
--

CREATE TABLE `orderbook` (
  `OrderID` varchar(10) DEFAULT NULL,
  `BookID` varchar(10) DEFAULT NULL,
  `Qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderbook`
--

INSERT INTO `orderbook` (`OrderID`, `BookID`, `Qty`) VALUES
('O-501', 'B-1', 1),
('O-501', 'B-2', 2),
('O-502', 'B-1', 3),
('O-503', 'B-3', 1),
('O-503', 'B-2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orderbook_1nf`
--

CREATE TABLE `orderbook_1nf` (
  `OrderID` varchar(10) NOT NULL,
  `OrderDate` date DEFAULT NULL,
  `CustID` varchar(10) DEFAULT NULL,
  `CustName` varchar(50) DEFAULT NULL,
  `CustEmail` varchar(100) DEFAULT NULL,
  `BookID` varchar(10) NOT NULL,
  `BookTitle` varchar(100) DEFAULT NULL,
  `Publisher` varchar(50) DEFAULT NULL,
  `UnitPrice` decimal(10,2) DEFAULT NULL,
  `Qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderbook_1nf`
--

INSERT INTO `orderbook_1nf` (`OrderID`, `OrderDate`, `CustID`, `CustName`, `CustEmail`, `BookID`, `BookTitle`, `Publisher`, `UnitPrice`, `Qty`) VALUES
('O-501', '2026-04-02', 'C-11', 'Bilal', 'bilal@x.com', 'B-1', 'SQL Basics', 'Pearson', 1200.00, 1),
('O-501', '2026-04-02', 'C-11', 'Bilal', 'bilal@x.com', 'B-2', 'Python 101', 'OReilly', 1500.00, 2),
('O-502', '2026-04-03', 'C-12', 'Areeba', 'areeba@x.com', 'B-1', 'SQL Basics', 'Pearson', 1200.00, 3),
('O-503', '2026-04-05', 'C-11', 'Bilal', 'bilal@x.com', 'B-2', 'Python 101', 'OReilly', 1500.00, 1),
('O-503', '2026-04-05', 'C-11', 'Bilal', 'bilal@x.com', 'B-3', 'Networks', 'Pearson', 1800.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orderbook_unf`
--

CREATE TABLE `orderbook_unf` (
  `OrderID` varchar(10) DEFAULT NULL,
  `OrderDate` date DEFAULT NULL,
  `CustID` varchar(10) DEFAULT NULL,
  `CustName` varchar(50) DEFAULT NULL,
  `CustEmail` varchar(100) DEFAULT NULL,
  `BookTitle` varchar(255) DEFAULT NULL,
  `BookID` varchar(255) DEFAULT NULL,
  `Publisher` varchar(255) DEFAULT NULL,
  `UnitPrice` varchar(255) DEFAULT NULL,
  `Qty` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderbook_unf`
--

INSERT INTO `orderbook_unf` (`OrderID`, `OrderDate`, `CustID`, `CustName`, `CustEmail`, `BookTitle`, `BookID`, `Publisher`, `UnitPrice`, `Qty`) VALUES
('O-501', '2026-04-02', 'C-11', 'Bilal', 'bilal@x.com', 'SQL Basics; Python 101', 'B-1; B-2', 'Pearson; OReilly', '1200; 1500', '1; 2'),
('O-502', '2026-04-03', 'C-12', 'Areeba', 'areeba@x.com', 'SQL Basics', 'B-1', 'Pearson', '1200', '3'),
('O-503', '2026-04-05', 'C-11', 'Bilal', 'bilal@x.com', 'Networks; Python 101', 'B-3; B-2', 'Pearson; OReilly', '1800; 1500', '1; 1');

-- --------------------------------------------------------

--
-- Table structure for table `orderitem_2nf`
--

CREATE TABLE `orderitem_2nf` (
  `OrderID` varchar(10) NOT NULL,
  `BookID` varchar(10) NOT NULL,
  `Qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderitem_2nf`
--

INSERT INTO `orderitem_2nf` (`OrderID`, `BookID`, `Qty`) VALUES
('O-501', 'B-1', 1),
('O-501', 'B-2', 2),
('O-502', 'B-1', 3),
('O-503', 'B-2', 1),
('O-503', 'B-3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orderitem_3nf`
--

CREATE TABLE `orderitem_3nf` (
  `OrderID` varchar(10) NOT NULL,
  `BookID` varchar(10) NOT NULL,
  `Qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderitem_3nf`
--

INSERT INTO `orderitem_3nf` (`OrderID`, `BookID`, `Qty`) VALUES
('O-501', 'B-1', 1),
('O-501', 'B-2', 2),
('O-502', 'B-1', 3),
('O-503', 'B-2', 1),
('O-503', 'B-3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` varchar(10) DEFAULT NULL,
  `OrderDate` date DEFAULT NULL,
  `CustID` varchar(10) DEFAULT NULL,
  `CustName` varchar(50) DEFAULT NULL,
  `CustEmail` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `OrderDate`, `CustID`, `CustName`, `CustEmail`) VALUES
('O-501', '2026-04-02', 'C-11', 'Bilal', 'bilal@x.com'),
('O-502', '2026-04-03', 'C-12', 'Areeba', 'areeba@x.com'),
('O-503', '2026-04-05', 'C-11', 'Bilal', 'bilal@x.com');

-- --------------------------------------------------------

--
-- Table structure for table `orders_2nf`
--

CREATE TABLE `orders_2nf` (
  `OrderID` varchar(10) NOT NULL,
  `OrderDate` date DEFAULT NULL,
  `CustID` varchar(10) DEFAULT NULL,
  `CustName` varchar(50) DEFAULT NULL,
  `CustEmail` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders_2nf`
--

INSERT INTO `orders_2nf` (`OrderID`, `OrderDate`, `CustID`, `CustName`, `CustEmail`) VALUES
('O-501', '2026-04-02', 'C-11', 'Bilal', 'bilal@x.com'),
('O-502', '2026-04-03', 'C-12', 'Areeba', 'areeba@x.com'),
('O-503', '2026-04-05', 'C-11', 'Bilal', 'bilal@x.com');

-- --------------------------------------------------------

--
-- Table structure for table `order_3nf`
--

CREATE TABLE `order_3nf` (
  `OrderID` varchar(10) NOT NULL,
  `OrderDate` date DEFAULT NULL,
  `CustID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_3nf`
--

INSERT INTO `order_3nf` (`OrderID`, `OrderDate`, `CustID`) VALUES
('O-501', '2026-04-02', 'C-11'),
('O-502', '2026-04-03', 'C-12'),
('O-503', '2026-04-05', 'C-11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`BookID`);

--
-- Indexes for table `book_2nf`
--
ALTER TABLE `book_2nf`
  ADD PRIMARY KEY (`BookID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustID`);

--
-- Indexes for table `orderbook_1nf`
--
ALTER TABLE `orderbook_1nf`
  ADD PRIMARY KEY (`OrderID`,`BookID`);

--
-- Indexes for table `orderitem_2nf`
--
ALTER TABLE `orderitem_2nf`
  ADD PRIMARY KEY (`OrderID`,`BookID`),
  ADD KEY `BookID` (`BookID`);

--
-- Indexes for table `orderitem_3nf`
--
ALTER TABLE `orderitem_3nf`
  ADD PRIMARY KEY (`OrderID`,`BookID`),
  ADD KEY `BookID` (`BookID`);

--
-- Indexes for table `orders_2nf`
--
ALTER TABLE `orders_2nf`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `order_3nf`
--
ALTER TABLE `order_3nf`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `CustID` (`CustID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orderitem_2nf`
--
ALTER TABLE `orderitem_2nf`
  ADD CONSTRAINT `orderitem_2nf_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `orders_2nf` (`OrderID`),
  ADD CONSTRAINT `orderitem_2nf_ibfk_2` FOREIGN KEY (`BookID`) REFERENCES `book_2nf` (`BookID`);

--
-- Constraints for table `orderitem_3nf`
--
ALTER TABLE `orderitem_3nf`
  ADD CONSTRAINT `orderitem_3nf_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `order_3nf` (`OrderID`),
  ADD CONSTRAINT `orderitem_3nf_ibfk_2` FOREIGN KEY (`BookID`) REFERENCES `book` (`BookID`);

--
-- Constraints for table `order_3nf`
--
ALTER TABLE `order_3nf`
  ADD CONSTRAINT `order_3nf_ibfk_1` FOREIGN KEY (`CustID`) REFERENCES `customer` (`CustID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
